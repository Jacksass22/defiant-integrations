import { Navigation } from '@/components/navigation';
import { ArrowRight, Clock, DollarSign, Phone, Calendar, MessageSquare, TrendingUp, CheckCircle, Droplets } from 'lucide-react';
import { Link } from 'wouter';
import { useScrollToTop } from '@/hooks/useScrollToTop';
import BlurText from '@/components/BlurText';
import { LeadCaptureModal } from '@/components/lead-capture-modal';
import { useState } from 'react';
import emergencyWorkflowImage from '@assets/image_1754935198774.png';

export default function Plumbing() {
  useScrollToTop();
  const [showLeadCaptureModal, setShowLeadCaptureModal] = useState(false);
  
  return (
    <div className="bg-white text-charcoal font-sans">
      <Navigation />
      {/* Hero Section */}
      <section className="relative min-h-[60vh] flex items-center pt-16 bg-gradient-to-br from-blue-900 via-blue-800 to-blue-900 overflow-hidden">
        {/* Tech Grid Pattern Overlay */}
        <div className="absolute inset-0 opacity-20">
          <svg className="w-full h-full" viewBox="0 0 100 100" preserveAspectRatio="none">
            <defs>
              <pattern id="tech-grid" x="0" y="0" width="10" height="10" patternUnits="userSpaceOnUse">
                <path d="M0,0 L10,0 M0,0 L0,10" stroke="rgba(255,255,255,0.3)" strokeWidth="0.5" fill="none" />
                <circle cx="5" cy="5" r="0.8" fill="rgba(255,255,255,0.2)" />
              </pattern>
            </defs>
            <rect width="100%" height="100%" fill="url(#tech-grid)" />
          </svg>
        </div>
        
        {/* Diagonal Lines Texture */}
        <div className="absolute inset-0 opacity-10">
          <svg className="w-full h-full" viewBox="0 0 100 100" preserveAspectRatio="none">
            <defs>
              <pattern id="diagonal-lines" x="0" y="0" width="20" height="20" patternUnits="userSpaceOnUse" patternTransform="rotate(45)">
                <line x1="0" y1="0" x2="0" y2="20" stroke="rgba(255,255,255,0.4)" strokeWidth="0.5" />
                <line x1="10" y1="0" x2="10" y2="20" stroke="rgba(255,255,255,0.2)" strokeWidth="0.3" />
              </pattern>
            </defs>
            <rect width="100%" height="100%" fill="url(#diagonal-lines)" />
          </svg>
        </div>
        
        {/* Floating Tech Elements */}
        <div className="absolute inset-0 opacity-15">
          <div className="absolute top-20 left-20 w-2 h-2 bg-white rounded-full animate-pulse"></div>
          <div className="absolute top-40 left-60 w-1 h-1 bg-blue-300 rounded-full animate-pulse" style={{ animationDelay: '0.5s' }}></div>
          <div className="absolute top-32 right-40 w-1.5 h-1.5 bg-white rounded-full animate-pulse" style={{ animationDelay: '1s' }}></div>
          <div className="absolute bottom-40 left-40 w-1 h-1 bg-blue-200 rounded-full animate-pulse" style={{ animationDelay: '1.5s' }}></div>
          <div className="absolute bottom-60 right-60 w-2 h-2 bg-white rounded-full animate-pulse" style={{ animationDelay: '2s' }}></div>
          
          {/* Connecting lines between elements */}
          <svg className="absolute inset-0 w-full h-full" viewBox="0 0 400 300">
            <line x1="80" y1="80" x2="240" y2="160" stroke="rgba(255,255,255,0.2)" strokeWidth="1" className="animate-pulse" />
            <line x1="240" y1="160" x2="320" y2="128" stroke="rgba(255,255,255,0.15)" strokeWidth="1" className="animate-pulse" style={{ animationDelay: '0.7s' }} />
            <line x1="160" y1="240" x2="320" y2="128" stroke="rgba(255,255,255,0.1)" strokeWidth="1" className="animate-pulse" style={{ animationDelay: '1.2s' }} />
          </svg>
        </div>
        
        <div className="absolute inset-0 bg-black/20"></div>
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-4xl">
            <BlurText
              text="Plumbing: Smart Technology That Actually Works for Your Business"
              delay={150}
              animateBy="words"
              direction="top"
              className="font-serif text-4xl sm:text-5xl lg:text-6xl xl:text-7xl font-bold mb-6 text-white leading-tight"
            />
            <p className="text-xl sm:text-2xl text-gray-200 mb-8 leading-relaxed">
              Handle more calls, keep customers informed, and grow your plumbing business without burning out.
            </p>
            <button 
              onClick={() => setShowLeadCaptureModal(true)}
              className="inline-flex items-center space-x-2 bg-white text-blue-900 px-8 py-4 font-medium hover:bg-gray-100 transition-colors"
            >
              <span>Start Your Free Assessment</span>
              <ArrowRight className="w-5 h-5" />
            </button>
          </div>
        </div>
      </section>
      {/* Problem Statement */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-4xl mx-auto">
            <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-bold text-gray-900 mb-8">
              The Plumbing Industry's Daily Reality
            </h2>
            <p className="text-lg sm:text-xl text-gray-600 mb-12 leading-relaxed">
              Running a plumbing company means dealing with emergencies at all hours, managing a crew that's scattered across town, and trying to keep customers happy when their pipes burst at the worst possible time. You're competing with the big franchises who have fancy systems while you're still juggling calls on your personal phone.
            </p>
            
            {/* Stats Grid */}
            <div className="grid md:grid-cols-2 gap-8 mb-12">
              <div className="bg-white p-8 shadow-lg">
                <div className="text-5xl font-bold text-blue-600 mb-4">60%</div>
                <h3 className="font-serif text-xl font-bold text-gray-900 mb-2">Emergency Calls</h3>
                <p className="text-gray-600">Of plumbing calls are urgent situations that can't wait</p>
              </div>
              <div className="bg-white p-8 shadow-lg">
                <div className="text-5xl font-bold text-blue-600 mb-4">24/7</div>
                <h3 className="font-serif text-xl font-bold text-gray-900 mb-2">Customer Expectations</h3>
                <p className="text-gray-600">Immediate responses and real-time updates</p>
              </div>
              <div className="bg-white p-8 shadow-lg">
                <div className="text-5xl font-bold text-blue-600 mb-4">70%</div>
                <h3 className="font-serif text-xl font-bold text-gray-900 mb-2">Missed Calls</h3>
                <p className="text-gray-600">Lost revenue from unanswered emergency calls</p>
              </div>
              <div className="bg-white p-8 shadow-lg">
                <div className="text-5xl font-bold text-blue-600 mb-4">3x</div>
                <h3 className="font-serif text-xl font-bold text-gray-900 mb-2">Competition</h3>
                <p className="text-gray-600">Big franchises with call centers and automated systems</p>
              </div>
            </div>

            <div className="bg-blue-900 text-white p-8 rounded-lg">
              <h3 className="font-serif text-2xl font-bold mb-4">What This Means for Your Business</h3>
              <ul className="space-y-3">
                <li className="flex items-start space-x-3">
                  <CheckCircle className="w-6 h-6 text-blue-300 flex-shrink-0 mt-0.5" />
                  <span>Emergency calls come in when you're already on a job</span>
                </li>
                <li className="flex items-start space-x-3">
                  <CheckCircle className="w-6 h-6 text-blue-300 flex-shrink-0 mt-0.5" />
                  <span>Customers get frustrated when they can't reach you immediately</span>
                </li>
                <li className="flex items-start space-x-3">
                  <CheckCircle className="w-6 h-6 text-blue-300 flex-shrink-0 mt-0.5" />
                  <span>Scheduling gets chaotic when emergencies bump regular appointments</span>
                </li>
                <li className="flex items-start space-x-3">
                  <CheckCircle className="w-6 h-6 text-blue-300 flex-shrink-0 mt-0.5" />
                  <span>You lose business to companies that answer the phone faster</span>
                </li>
                <li className="flex items-start space-x-3">
                  <CheckCircle className="w-6 h-6 text-blue-300 flex-shrink-0 mt-0.5" />
                  <span>Administrative work eats up time you could spend plumbing</span>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </section>
      {/* Solutions Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-bold text-gray-900 mb-4">
              How Smart Technology Fixes These Problems
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Transform your plumbing operations with AI-powered solutions designed for emergency response
            </p>
          </div>

          {/* Solution Cards */}
          <div className="space-y-20">
            {/* Solution 1 */}
            <div className="grid lg:grid-cols-2 gap-12 items-center">
              <div>
                <div className="inline-flex items-center justify-center w-16 h-16 bg-blue-100 text-blue-600 rounded-lg mb-6">
                  <Phone className="w-8 h-8" />
                </div>
                <h3 className="font-serif text-2xl sm:text-3xl font-bold text-gray-900 mb-4">
                  Never Miss Another Emergency Call
                </h3>
                <p className="text-lg text-gray-600 mb-6">
                  <strong>The Problem:</strong> Customers with burst pipes don't wait - they call the next plumber
                </p>
                <p className="text-lg text-gray-600 mb-6">
                  <strong>The Solution:</strong> AI phone systems that answer every call and handle urgent situations properly
                </p>
                <div className="bg-gray-50 p-6 rounded-lg mb-6">
                  <h4 className="font-semibold text-gray-900 mb-3">What This Looks Like:</h4>
                  <ul className="space-y-2 text-gray-600">
                    <li>• AI answers calls 24/7, even when you're under a sink</li>
                    <li>• Emergency calls get prioritized and you're notified immediately</li>
                    <li>• Service calls can be booked directly, messages taken for complex issues, quotes provided for standard jobs</li>
                    <li>• Routine questions (hours, pricing, services) get answered instantly</li>
                    <li>• Only calls that need human attention get transferred. You decide. </li>
                    <li>• Customer information gets captured automatically for follow-up</li>
                  </ul>
                </div>
                <div className="bg-blue-50 border-l-4 border-blue-600 p-4">
                  <p className="text-blue-900 font-semibold">
                    Real Results: 70% fewer missed calls and 50% more emergency bookings
                  </p>
                </div>
              </div>
              <div className="bg-gradient-to-br from-blue-600 to-blue-800 h-96 rounded-lg flex items-center justify-center">
                <Phone className="w-32 h-32 text-white/20" />
              </div>
            </div>

            {/* Solution 2 */}
            <div className="grid lg:grid-cols-2 gap-12 items-center">
              <div className="order-2 lg:order-1 h-96 rounded-lg overflow-hidden">
                <img 
                  src={emergencyWorkflowImage}
                  alt="Emergency call handling workflow showing headset support, phone calls, warning alerts, customer profiles, messaging, and plumbing services"
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="order-1 lg:order-2">
                <div className="inline-flex items-center justify-center w-16 h-16 bg-green-100 text-green-600 rounded-lg mb-6">
                  <Calendar className="w-8 h-8" />
                </div>
                <h3 className="font-serif text-2xl sm:text-3xl font-bold text-gray-900 mb-4">
                  Smart Scheduling for Chaos Management
                </h3>
                <p className="text-lg text-gray-600 mb-6">
                  <strong>The Problem:</strong> Emergency calls destroy your schedule and upset regular customers
                </p>
                <p className="text-lg text-gray-600 mb-6">
                  <strong>The Solution:</strong> Intelligent scheduling that adapts to emergencies while keeping customers informed
                </p>
                <div className="bg-gray-50 p-6 rounded-lg mb-6">
                  <h4 className="font-semibold text-gray-900 mb-3">What This Looks Like:</h4>
                  <ul className="space-y-2 text-gray-600">
                    <li>• Automatic appointment confirmations and reminders via text/email</li>
                    <li>• When emergencies happen, affected customers get instant updates</li>
                    <li>• Easy rescheduling with automatic notifications</li>
                    <li>• Calendar that syncs across your whole team</li>
                    <li>• Customers can book non-emergency appointments online</li>
                  </ul>
                </div>
                <div className="bg-green-50 border-l-4 border-green-600 p-4">
                  <p className="text-green-900 font-semibold">
                    Real Results: 40% fewer no-shows and happier customers even when schedules change
                  </p>
                </div>
              </div>
            </div>

            {/* Solution 3 */}
            <div className="grid lg:grid-cols-2 gap-12 items-center">
              <div>
                <div className="inline-flex items-center justify-center w-16 h-16 bg-purple-100 text-purple-600 rounded-lg mb-6">
                  <MessageSquare className="w-8 h-8" />
                </div>
                <h3 className="font-serif text-2xl sm:text-3xl font-bold text-gray-900 mb-4">
                  Instant Estimates and Professional Communication
                </h3>
                <p className="text-lg text-gray-600 mb-6">
                  <strong>The Problem:</strong> Customers want pricing immediately, but you're busy working
                </p>
                <p className="text-lg text-gray-600 mb-6">
                  <strong>The Solution:</strong> AI that provides accurate estimates and maintains professional communication
                </p>
                <div className="bg-gray-50 p-6 rounded-lg mb-6">
                  <h4 className="font-semibold text-gray-900 mb-3">What This Looks Like:</h4>
                  <ul className="space-y-2 text-gray-600">
                    <li>• AI provides ballpark pricing for common jobs over the phone</li>
                    <li>• Automated follow-up emails with detailed estimates</li>
                    <li>• Professional text updates: "On our way," "Running 15 minutes late," "Job complete"</li>
                    <li>• Automatic invoicing and payment reminders</li>
                    <li>• Review requests sent automatically after successful jobs</li>
                  </ul>
                </div>
                <div className="bg-purple-50 border-l-4 border-purple-600 p-4">
                  <p className="text-purple-900 font-semibold">
                    Real Results: 60% faster estimate delivery and 3x more positive reviews
                  </p>
                </div>
              </div>
              <div className="bg-gradient-to-br from-purple-600 to-purple-800 h-96 rounded-lg flex items-center justify-center">
                <MessageSquare className="w-32 h-32 text-white/20" />
              </div>
            </div>

            {/* Solution 4 */}
            <div className="grid lg:grid-cols-2 gap-12 items-center">
              <div className="order-2 lg:order-1 bg-gradient-to-br from-orange-600 to-orange-800 h-96 rounded-lg flex items-center justify-center">
                <Droplets className="w-32 h-32 text-white/20" />
              </div>
              <div className="order-1 lg:order-2">
                <div className="inline-flex items-center justify-center w-16 h-16 bg-orange-100 text-orange-600 rounded-lg mb-6">
                  <TrendingUp className="w-8 h-8" />
                </div>
                <h3 className="font-serif text-2xl sm:text-3xl font-bold text-gray-900 mb-4">
                  Turn One-Time Emergencies Into Regular Customers
                </h3>
                <p className="text-lg text-gray-600 mb-6">
                  <strong>The Problem:</strong> Customers only call when something breaks, then forget about you
                </p>
                <p className="text-lg text-gray-600 mb-6">
                  <strong>The Solution:</strong> Automated relationship building that keeps you top-of-mind
                </p>
                <div className="bg-gray-50 p-6 rounded-lg mb-6">
                  <h4 className="font-semibold text-gray-900 mb-3">What This Looks Like:</h4>
                  <ul className="space-y-2 text-gray-600">
                    <li>• Maintenance reminders for water heaters, sump pumps, and seasonal issues</li>
                    <li>• Educational emails about preventing common plumbing problems</li>
                    <li>• Special offers for past customers during slow seasons</li>
                    <li>• Automatic follow-up: "How's everything working since our visit?"</li>
                    <li>• Birthday and holiday messages that build personal connections</li>
                  </ul>
                </div>
                <div className="bg-orange-50 border-l-4 border-orange-600 p-4">
                  <p className="text-orange-900 font-semibold">
                    Real Results: 50% more repeat customers and 40% increase in maintenance work
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      {/* Implementation Timeline */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-bold text-gray-900 mb-4">
              How We Get You There
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              A proven 90-day implementation roadmap designed for minimal disruption and maximum impact
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto">
            <div className="bg-white p-8 shadow-lg">
              <div className="text-blue-600 font-bold text-lg mb-2">Month 1</div>
              <h3 className="font-serif text-2xl font-bold text-gray-900 mb-4">Set Up Your Phone System</h3>
              <ul className="space-y-3 text-gray-600">
                <li className="flex items-start space-x-2">
                  <CheckCircle className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
                  <span>AI phone answering system handles basic questions and emergencies</span>
                </li>
                <li className="flex items-start space-x-2">
                  <CheckCircle className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
                  <span>Integrate with your calendar and customer database</span>
                </li>
                <li className="flex items-start space-x-2">
                  <CheckCircle className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
                  <span>Set up automatic appointment confirmations and reminders</span>
                </li>
              </ul>
            </div>

            <div className="bg-white p-8 shadow-lg">
              <div className="text-blue-600 font-bold text-lg mb-2">Month 2</div>
              <h3 className="font-serif text-2xl font-bold text-gray-900 mb-4">Add Smart Communication</h3>
              <ul className="space-y-3 text-gray-600">
                <li className="flex items-start space-x-2">
                  <CheckCircle className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
                  <span>Launch automated follow-up sequences for estimates and completed jobs</span>
                </li>
                <li className="flex items-start space-x-2">
                  <CheckCircle className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
                  <span>Create maintenance reminder campaigns</span>
                </li>
                <li className="flex items-start space-x-2">
                  <CheckCircle className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
                  <span>Set up professional text messaging for job updates</span>
                </li>
              </ul>
            </div>

            <div className="bg-white p-8 shadow-lg">
              <div className="text-blue-600 font-bold text-lg mb-2">Month 3+</div>
              <h3 className="font-serif text-2xl font-bold text-gray-900 mb-4">Watch Your Business Transform</h3>
              <ul className="space-y-3 text-gray-600">
                <li className="flex items-start space-x-2">
                  <CheckCircle className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
                  <span>Handle more calls without hiring office staff</span>
                </li>
                <li className="flex items-start space-x-2">
                  <CheckCircle className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
                  <span>Customers stay informed and happy even during emergencies</span>
                </li>
                <li className="flex items-start space-x-2">
                  <CheckCircle className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
                  <span>Regular maintenance work fills gaps between emergency calls</span>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </section>
      {/* ROI Section */}
      <section className="py-20 bg-blue-900 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-bold mb-4">
              What This Actually Means for Your Bottom Line
            </h2>
          </div>

          <div className="grid lg:grid-cols-3 gap-8">
            <div className="bg-blue-800/50 p-8 rounded-lg">
              <Clock className="w-12 h-12 text-blue-300 mb-4" />
              <h3 className="font-serif text-2xl font-bold mb-4">Time You'll Save</h3>
              <ul className="space-y-3 text-gray-200">
                <li>• <strong>Phone management:</strong> AI handles 70% of calls without your involvement</li>
                <li>• <strong>Scheduling chaos:</strong> Automated updates when emergencies disrupt the schedule</li>
                <li>• <strong>Follow-up work:</strong> Automatic estimate delivery and payment reminders</li>
                <li>• <strong>Customer service:</strong> Professional communication happens automatically</li>
              </ul>
            </div>

            <div className="bg-blue-800/50 p-8 rounded-lg">
              <DollarSign className="w-12 h-12 text-blue-300 mb-4" />
              <h3 className="font-serif text-2xl font-bold mb-4">Money You'll Make</h3>
              <ul className="space-y-3 text-gray-200">
                <li>• <strong>More emergency calls:</strong> Never miss urgent work because you couldn't answer</li>
                <li>• <strong>Higher conversion:</strong> Instant responses convert more callers to customers</li>
                <li>• <strong>Repeat business:</strong> Automated relationship building brings customers back</li>
                <li>• <strong>Premium pricing:</strong> Professional systems justify higher rates</li>
              </ul>
            </div>

            <div className="bg-blue-800/50 p-8 rounded-lg">
              <TrendingUp className="w-12 h-12 text-blue-300 mb-4" />
              <h3 className="font-serif text-2xl font-bold mb-4">Competitive Advantages</h3>
              <ul className="space-y-3 text-gray-200">
                <li>• Answer calls instantly while competitors miss them</li>
                <li>• Provide professional communication that big franchises offer</li>
                <li>• Turn emergencies into long-term customer relationships</li>
                <li>• Handle more volume without hiring office staff</li>
              </ul>
            </div>
          </div>
        </div>
      </section>
      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-br from-gray-900 to-gray-800 text-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-bold mb-6">
            The Bottom Line
          </h2>
          <p className="text-xl mb-8 leading-relaxed text-gray-300">
            Plumbing emergencies happen on their schedule, not yours. But your customer service doesn't have to suffer because you're busy fixing pipes. Your customers want fast responses, clear communication, and someone they can trust.
          </p>
          <p className="text-xl mb-8 leading-relaxed text-gray-300">
            Smart automation handles the business side so you can focus on what you do best - solving plumbing problems. While your competitors are missing calls and losing customers, you'll be the plumber who's always available and always professional.
          </p>
          <p className="text-2xl font-semibold mb-12">
            Ready to see what this looks like for your business?
          </p>
          <button 
            onClick={() => setShowLeadCaptureModal(true)}
            className="inline-flex items-center space-x-2 bg-blue-600 text-white px-8 py-4 font-medium hover:bg-blue-700 transition-colors text-lg"
          >
            <span>Start Your Free Assessment</span>
            <ArrowRight className="w-5 h-5" />
          </button>
        </div>
      </section>
      {/* Lead Capture Modal */}
      <LeadCaptureModal
        open={showLeadCaptureModal}
        onOpenChange={setShowLeadCaptureModal}
        title="Transform Your Plumbing Business"
        subtitle="Get a customized assessment for your plumbing company"
      />
      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12 sm:py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-6 sm:gap-8">
            <div className="col-span-2 sm:col-span-3 lg:col-span-2">
              <div className="text-xl sm:text-2xl font-serif font-bold mb-4">
                Defiant <span className="text-gray-300">Integrations</span>
              </div>
              <p className="text-gray-400 mb-6 text-sm sm:text-base">
                Architecting intelligent transformations that scale.
              </p>
            </div>
            
            <div>
              <h4 className="font-semibold mb-4">Industries</h4>
              <ul className="space-y-2 text-gray-400 text-sm">
                <li><Link href="/hvac" className="hover:text-blue-400 transition-colors">HVAC</Link></li>
                <li><Link href="/plumbing" className="hover:text-blue-400 transition-colors">Plumbing</Link></li>
                <li><Link href="/electrical" className="hover:text-blue-400 transition-colors">Electrical</Link></li>
                <li><Link href="/roofing" className="hover:text-blue-400 transition-colors">Roofing</Link></li>
                <li><Link href="/landscaping" className="hover:text-blue-400 transition-colors">Landscaping</Link></li>
              </ul>
            </div>
            
            <div>
              <h4 className="font-semibold mb-4">Capabilities</h4>
              <ul className="space-y-2 text-gray-400 text-sm">
                <li><Link href="/ai-strategy-development" className="hover:text-blue-400 transition-colors">AI Strategy</Link></li>
                <li><Link href="/system-integration" className="hover:text-blue-400 transition-colors">Implementation</Link></li>
                <li><Link href="/change-management" className="hover:text-blue-400 transition-colors">Scaling</Link></li>
              </ul>
            </div>
            
            <div>
              <h4 className="font-semibold mb-4">About Us</h4>
              <ul className="space-y-2 text-gray-400 text-sm">
                <li><button className="hover:text-blue-400 transition-colors">Careers</button></li>
                <li><button className="hover:text-blue-400 transition-colors">Contact</button></li>
                <li><button className="hover:text-blue-400 transition-colors">Blog</button></li>
              </ul>
            </div>
            
            <div>
              <h4 className="font-semibold mb-4">Connect</h4>
              <ul className="space-y-2 text-gray-400 text-sm">
                <li><button className="hover:text-blue-400 transition-colors">Subscribe</button></li>
              </ul>
            </div>
          </div>
          
          <div className="border-t border-gray-700 mt-12 pt-8 text-center text-gray-400 text-sm">
            <p>&copy; 2025 Defiant Integrations. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}